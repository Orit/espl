#ifndef FONT_H
#define FONT_H

#define SYMBOL_HEIGHT 6

extern char *alphabet[][SYMBOL_HEIGHT];

#endif

